export class Product {
   public product_name: String = '';
   public product_price: String = '';
   public product_category: String = '';
   public manufacturer: String = '';
}
